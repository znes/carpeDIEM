<?php
$subsystem_scenarionumber_max=7;

$subsystem_scenarionumber=$_GET['subsystem_scenarionumber'];
$rl=$_GET['rl'];
$region=$_GET['region'];
$sort=$_GET['sort'];

$columnname_subsystem = "rl_scenario0".$subsystem_scenarionumber;
$columnname_mainsystem = "rl".$rl."_".$region;

ini_set('memory_limit', '512M');

$i=0;
$a=0;
require("inc/#_mysql_data.inc");

$tabname = "results_sequences_evaluation_".$region;
$columnname_evaluation = "scenario0".$subsystem_scenarionumber."_rl".$rl;
$query = "SELECT $columnname_evaluation FROM $tabname";
$queryresult = mysqli_query($mysqli, $query);
$row_cnt = $queryresult->num_rows;
for($i=1; $i<=$row_cnt; $i++)
{
  $result_evaluation[$i]=mysqli_fetch_array($queryresult, MYSQLI_BOTH);
}

//general diagram data
$diagram_width = 800;
$diagram_height = 600;
$diagram_title = "Heatmap";
$name_x_axis = "d";
$name_y_axis = "h";
$font = 2;
$textwidth_name_x_axis=strlen($name_x_axis) * imagefontwidth($font);
$counter_hours=1;
$counter_days=1;

//margins & padding
$margin = 30;
$padding_top = 10;
$padding_left = 10;
$padding_bottom = 10;
$padding_right = 10;
$margin_intern = 0;

//diagram colours
$backgroundcolour_r = 255;
$backgroundcolour_g = 255;
$backgroundcolour_b = 255;
$backgroundcolour_result_r = 255;
$backgroundcolour_result_g = 255;
$backgroundcolour_result_b = 255;
$textcolour_r = 64;
$textcolour_g = 64;
$textcolour_b = 64;
$axiscolour_r = 0;
$axiscolour_g = 0;
$axiscolour_b = 0;
$barcolour_r = 32;
$barcolour_g = 128;
$barcolour_b = 196;
$barcolour_negative_r = 255;
$barcolour_negative_g = 0;
$barcolour_negative_b = 0;
$barcolour_neutral_r = 255;
$barcolour_neutral_g = 255;
$barcolour_neutral_b = 255;
$barcolour_positive_r = 65;
$barcolour_positive_g = 105;
$barcolour_positive_b = 225;

$barthickness=12;
$bardistance = 2 * $barthickness;

$i=1;
for ($i=1; $i<=$row_cnt; $i++)
{
  $x_values[] = $i;
  $y_values_evaluation[] = $result_evaluation[$i][$columnname_evaluation];
}

//defining maximum and minimum values x 
$tmp = $x_values;
sort($tmp);
$x_min = $tmp[0];
rsort($tmp);
$x_max = $tmp[0];

$x_min_round=round($x_min);
$x_max_round=round($x_max);
$x_min_round_display=number_format($x_min_round,0,".",",");
$x_max_round_display=number_format($x_max_round,0,".",",");
$textwidth_x_max_round_display=strlen($x_max_round_display) * imagefontwidth($font);

//defining maximum and minimum values y
$y_min = -1;
$y_max = 1;

$y_min_round=round($y_min);
$y_max_round=round($y_max);
$y_min_round_display=number_format($y_min_round,0,".",",");
$y_max_round_display=number_format($y_max_round,0,".",",");
$textwidth_y_max_round_display=strlen($y_max_round_display) * imagefontwidth($font);

$zero=0;
$zero_display=number_format($zero,0,".",",");

//defining content-type for web-browser
$image = imagecreate ($diagram_width, $diagram_height);
header ( 'Content-Type: image/png' );

//defining colours
$textcolour = imagecolorallocate($image, $textcolour_r, $textcolour_g, $textcolour_b);
$backgroundcolour = imagecolorallocate($image, $backgroundcolour_r, $backgroundcolour_g, $backgroundcolour_b);
$backgroundcolour_result = imagecolorallocate($image, $backgroundcolour_result_r, $backgroundcolour_result_g, $backgroundcolour_result_b);
$axiscolour = imagecolorallocate($image, $axiscolour_r, $axiscolour_g, $axiscolour_b);
$barcolour = imagecolorallocate($image, $barcolour_r, $barcolour_g, $barcolour_b);
$barcolour_negative = imagecolorallocate($image, $barcolour_negative_r, $barcolour_negative_g, $barcolour_negative_b);
$barcolour_neutral = imagecolorallocate($image, $barcolour_neutral_r, $barcolour_neutral_g, $barcolour_neutral_b);
$barcolour_positive = imagecolorallocate($image, $barcolour_positive_r, $barcolour_positive_g, $barcolour_positive_b);

//colouring areas displayed
imagefill($image, 0, 0, $backgroundcolour);
imagefilledrectangle($image, $margin+$padding_left+$margin_intern, $margin+$padding_top, $diagram_width-$margin-$padding_right, $diagram_height-$margin-$padding_bottom, $backgroundcolour_result);

//general calculations of x and y axis
$span=365;
$relation=$span/($diagram_width-2*$margin-$padding_right-$padding_left-$margin_intern);
$distance_left=abs($x_min/$relation);
$span_y=24;
$relation_y=$span_y/($diagram_height-2*$margin-$padding_top-$padding_bottom-$margin_intern);

//Achsenbeschriftung /Skala   
//draw values 
$i=1;
for ($i=1;$i<=$row_cnt;$i++)
{
    $barcolour=$barcolour;
    if ($y_values_evaluation[$i-1]<0)
    {
      $barcolour=$barcolour_negative;
    }
    elseif ($y_values_evaluation[$i-1]==0)
    {
      $barcolour=$barcolour_neutral;
    }
    elseif ($y_values_evaluation[$i-1]>0)
    {
      $barcolour=$barcolour_positive;
    }
  imagefilledrectangle($image,
    $margin+$padding_left+$margin_intern+$distance_left+$counter_days/$relation,
    $margin+$padding_top+$margin_intern+($counter_hours/$relation_y),
    $margin+$padding_left+$margin_intern+$distance_left+$counter_days/$relation-1/$relation,
    $margin+$padding_top+$margin_intern+($counter_hours/$relation_y)-1/$relation_y,
    $barcolour);
    if ($counter_hours<24)
    {
      $counter_hours=$counter_hours+1;
    }
    else
    {
      $counter_hours=1;
      $counter_days=$counter_days+1;
    }
  
//  imagestring($image, 2,
//    $margin+$padding_left-15,
//    $margin+$padding_top+$margin_intern+5*$i,
//    $rl, $textcolour);
}

//imagestring($image, 2, $margin-5,
  //$diagram_height-$margin-$padding_bottom+10, 1, $textcolour);

imagestring($image, 2, $margin+$padding_left+$margin_intern+$distance_left+1-(0.5*imagefontwidth($font)),
  $diagram_height-$margin-$padding_bottom+5, 1, $textcolour);

imagestring($image, 2, $diagram_width-$margin-$padding_right-15,
  $diagram_height-$margin-$padding_bottom+5, 365, $textcolour);

imagestring($image, 2, $margin-5,
  $margin+$padding_top+$margin_intern, 1, $textcolour);

imagestring($image, 2, $margin-5,
  $margin+$padding_top+$margin_intern+($span_y/$relation_y)-10, 23, $textcolour);

imagestring($image, 2, $diagram_width-$margin-$padding_right,
  $diagram_height-$margin-$padding_bottom+20, $name_x_axis, $textcolour);

imagestring($image, 2, 10,
  $margin+$padding_top+$margin_intern, $name_y_axis, $textcolour);

//draw y-axis
imageline($image, $margin+$padding_left+$margin_intern, $margin+$padding_top, $margin+$padding_left+$margin_intern, $diagram_height-$margin-$padding_bottom, $axiscolour);

//draw x-axis
imageline($image, $margin+$padding_left+$margin_intern, $margin+$padding_top+$margin_intern+($span_y/$relation_y), $diagram_width-$margin-$padding_right, $margin+$padding_top+$margin_intern+($span_y/$relation_y), $axiscolour);

//display image
imagepng ($image);
imagedestroy($image); 
 
?>
