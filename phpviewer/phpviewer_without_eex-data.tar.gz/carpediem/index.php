<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" >
<head>
 <meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
 <meta name="author" content="Dr. Sönke Bohm" />
 <meta name="keywords" content="" />
 <meta name="description" content="" />
 <meta name="robots" content="all" />
 <title>carpeDIEM</title>
 <link rel="Shortcut Icon" type="image/x-icon" href="favicon.ico" />
 <link href="css/css1.css" type=text/css rel=stylesheet>
  <script language="JavaScript">
  <!--
  function QuickJump(Formular)
  {
  	var Element = Formular.ziel.selectedIndex;
  	if (Formular.ziel.options[Element].value != 0) 
  	{
  		location = Formular.ziel.options[Element].value;
  	}	
  }
  //-->
  </script>
</head>
<body id="body">
<?php
  error_reporting(E_ERROR | E_WARNING | E_PARSE);
  $self=$_SERVER['PHP_SELF'];
  $stylesheet_no=1;
  $language="eng";
  $div=$_GET['div'];
  $cat1=$_GET['cat1'];
  $cat2=$_GET['cat2'];
  $cat3=$_GET['cat3'];
  $pic=$_GET['pic'];
  include("inc/#_mysql_menu.inc");

  $query = "SELECT * FROM $tabname";
  $queryresult = mysqli_query($mysqli, $query);
  $row_cnt = $queryresult->num_rows;
  for($i=0; $i<$row_cnt; $i++)
  {
    $result[$i]=mysqli_fetch_array($queryresult, MYSQLI_BOTH);
  }
  $i=0;
  $id_division="-1";
  for ($i=0; $i<$row_cnt; $i++)
  {
    $name_check=$result[$i]['name'];
    $id=$result[$i]['id'];
    if ($div == $name_check)
    {
      $id_division=$div;
    }
  }
  if ($id_division<=0)
  {
    $id_division=0;
    $div=0;
  }
  $i=0;
  if (isset($cat1))
  {
    for ($i=0; $i<$row_cnt; $i++)
    {
      $name_check=$result[$i]['name'];
      $category_1_check=$result[$i]['category_1'];
      $id1_check=$result[$i]['id'];
      if ($id_division==$category_1_check AND $name_check==$cat1)
      {
        $counter=$counter+1;
        $cat1_sel=$id1_check;
      }
    }
    if ($counter==0)
    {
      $cat1=0;
    }
  }
  else
  {
    $cat1=0;
  }
  $i=0;
  $counter=0;
  if (isset($cat2))
  {
    for ($i=0; $i<$row_cnt; $i++)
    {
      $name_check=$result[$i]['name'];
      $category_2_check=$result[$i]['category_2'];
      $id2_check=$result[$i]['id'];
      if ($cat1_sel==$category_2_check AND $name_check==$cat2)
      {
        $counter=$counter+1;
        $cat2_sel=$id2_check;
      }
    }
    if ($counter==0)
    {
      $cat2=0;
    }
  }
  else
  {
    $cat2=0;
  }
  $i=0;
  $counter=0;
  if (isset($cat3))
  {
    for ($i=0; $i<$row_cnt; $i++)
    {
      $name_check=$result[$i]['name'];
      $category_3_check=$result[$i]['category_3'];
      $id3_check=$result[$i]['id'];
      if ($cat2_sel==$category_3_check AND $name_check==$cat3)
      {
        $counter=$counter+1;
      }
    }
    if ($counter==0)
    {
      $cat3=0;
    }
  }
  else
  {
    $cat3=0;
  }
  $query = "SELECT * FROM $tabname";
  $queryresult = mysqli_query($mysqli, $query);
  $row_cnt = $queryresult->num_rows;
  for($i=0; $i<$row_cnt; $i++)
  {
    $result[$i]=mysqli_fetch_array($queryresult, MYSQLI_BOTH);
  }
  $i=0;
  for ($i=0; $i<$row_cnt; $i++)
  {
    $id=$result[$i]['id'];
    $namex=$result[$i]['name'];
    $display_namex=$result[$i][$language];
    $divisionx=$result[$i]['division'];
    $idx=$result[$i]['id'];
    $divisionx=$result[$i]['division'];
    $category_1x=$result[$i]['category_1'];
    $category_2x=$result[$i]['category_2'];
    $category_3x=$result[$i]['category_3'];
    $sub_language="sub_".$language;
    $sub=$result[$i][$sub_language];
    if ($id==$div)
    {
      $sub1=$sub;
      $display_namex_selected=$display_namex;
      $idx_selected=$idx;
    }
    if ($cat1!=0)
    {
      if ($category_1x==$idx_selected)
      {
        if ($cat1==$namex)
        {
          $sub_lev1=$sub;
          $display_namexlev1=$display_namex;
          $idx_lev1=$idx;
        }
      }
    }
    if ($cat2!=0)
    {
      if ($category_2x==$idx_lev1)
      {
        if ($cat2==$namex)
        {
          $sub_lev2=$sub;
          $display_namexlev2=$display_namex;
          $idx_lev2=$idx;
        }
      }
    }
    if ($cat3!=0)
    {
      if ($category_3x==$idx_lev2)
      {
        if ($cat3==$namex)
        {
          $sub_lev3=$sub;
          $display_namexlev3=$display_namex;
        }
      }
    }   
  }
  echo "<a name=\"top\"></a>";
  echo "<div id=\"container\">";
  echo "<div id=\"header\">";
  echo "<span class=\"header\">";
  echo "<a href=\"index.php?div=0\" alt=\"\" title=\"\">";
  echo "<img src=\"images/website/logo.png\" alt=\"\" title=\"\"></a></span>";
  echo "</div>";
  echo "<div id=\"left\">";
  echo "<div id=\"navigation\">";
  echo "<ul id=\"navlist\">";
                                                                                               //Main menu
  include("inc/#_mysql_menu.inc");
  $query = "SELECT * FROM $tabname";
  $queryresult = mysqli_query($mysqli, $query);
  $row_cnt = $queryresult->num_rows;
  for($i=0;$i<$row_cnt;$i++)
  {
    $result[$i]=mysqli_fetch_array($queryresult, MYSQLI_BOTH);
  }
  $i=0;
  echo "<li class=\"lev1\">";
  echo "<a href=\"";
  echo "$self";
  echo "?div=0\" alt=\"Home\" title=\"Home\">Home</a>";
  echo "</li>";
  for ($i=0; $i<$row_cnt; $i++)
  {
    $id=$result[$i]['id'];
    $name=$result[$i]['name'];
    $display_name=$result[$i][$language];
    if ($result[$i]['division']==1)
    {
      echo "<li class=\"lev1\">";
      echo "<a href=\"";
      echo "$self";
      echo "?div=$name&cat1=0\" alt=\"\" title=\"\">$display_name</a>";
      echo "</li>";
      if ($div==$id)
      {
        for ($a=0; $a<$row_cnt; $a++)
        {
          $display_name_lev1=$result[$a][$language];
          $category_1=$result[$a]['category_1'];
          $name1=$result[$a]['name'];
          $id1=$result[$a]['id'];
          if ($category_1==$id)
          {
            echo "<li class=\"lev2\">";
            echo "<a href=\"";
            echo "$self";
            echo "?&div=$div&cat1=$name1\" alt=\"\"
              title=\"\">$display_name_lev1</a>";
            echo "</li>";
            if ($cat1==$name1)
            {
              for ($b=0; $b<$row_cnt; $b++)
              {
                $display_name_lev2=$result[$b][$language];
                $category_2=$result[$b]['category_2'];
                $name2=$result[$b]['name'];
                $id2=$result[$b]['id'];
                if ($category_2==$id1)
                {
                  echo "<li class=\"lev3\">";
                  echo "<a href=\"";
                  echo "$self";
                  echo "?div=$div&cat1=$name1&cat2=$name2\" alt=\"\"
                    title=\"\">$display_name_lev2</a>";
                  echo "</li>";
                  if ($cat2==$name2)
                  {
                    for ($c=0; $c<$row_cnt; $c++)
                    {
                      $display_name_lev3=$result[$c][$language];
                      $category_3=$result[$c]['category_3'];
                      $name3=$result[$c]['name'];
                      if ($category_3==$id2)
                      {
                        echo "<li class=\"lev4\">";
                        echo "<a href=\"";
                        echo "$self";
                        echo "?language=$language&style=$stylesheet_no&div=$div&cat1=$name1&cat2=$name2&cat3=$name3\"
                          alt=\"\" title=\"\">$display_name_lev3</a>";
                        echo "</li>";
                      }
                    }
                  }
                }
              }
            }  
          }
        }
      }
    }
  }
  echo "</ul>";
  echo "</div>";
  echo "</div>";
  echo "<div id=\"main\">";
  echo "<div id=\"location\">";
  echo "<a href=\"$self?div=0\" alt=\"\" title=\"\">";
  echo "Home";
  echo "</a>";
  if ($div!=0)
  {
    echo " » <a href=\"$self?div=$div&cat1=0\" alt=\"\"
      title=\"\">$display_namex_selected</a>";
  }
  if ($cat1!=0)
  {
    echo " » <a href=\"$self?div=$div&cat1=$cat1\" alt=\"\"
      title=\"\">$display_namexlev1</a>";
  }
  if ($cat2!=0)
  {
    echo " » <a href=\"$filename?div=$div&cat1=$cat1&cat2=$cat2\" alt=\"\"
      title=\"\">$display_namexlev2</a>";
  }
  if ($cat3!=0)
  {
    echo " » <a href=\"$self?div=$div&cat1=$cat1&cat2=$cat2&cat3=$cat3\" alt=\"\"
      title=\"\">$display_namexlev3</a>";
  }
  echo "</div>";
  echo "<div id=\"title\">";
  echo "<p class=\"title\">";
  if ($cat1!=0)
  {
    if ($cat2!=0)
    {
      if ($cat3!=0)
      {
        echo "$sub_lev3";
      }
      else
      {
        echo "$sub_lev2";
      }
    }
    else
    {
      echo "$sub_lev1";
    }
  }
  else
  {
    echo "$sub1";
  }
  if ($div==0)
  {
    echo "Welcome text";
  }
  echo "</p>";
  echo "</div>";
  echo "<div id=\"content\">";
  $includefile="inc/#_".$div.".inc";
  include ($includefile);
  echo "</div>";
  echo "<div id=\"gototop\">";
  echo "<p class=\"gototop\"><a href=\"#top\"><img class=\"top\" src=\"images/website/navi_top.gif\"></a></p>";
  echo "</div>";
  echo "</div>";
  echo "<div id=\"footer\">";
  echo "<p><a href=\"http://jigsaw.w3.org/css-validator/\"><img style=\"border:0;width:88px;height:31px\"
    src=\"http://jigsaw.w3.org/css-validator/images/vcss\" alt=\"Valid CSS!\" /></a></p>";
  echo "Europa-Universit&auml;t Flensburg 2018";
  echo "</div>";
$directory = "./inc/";
$handle=opendir ($directory);
?>
</body>
</html>
